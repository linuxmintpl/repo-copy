var searchData=
[
  ['name',['name',['../structgg__multilogon__session.html#a5ac083a645d964373f022d03df4849c8',1,'gg_multilogon_session']]],
  ['name_5fsize',['name_size',['../structgg__multilogon__info__item.html#a61d946be12b0272d3f3da5653a5e6a9e',1,'gg_multilogon_info_item']]],
  ['network_2ec',['network.c',['../network_8c.html',1,'']]],
  ['network_2eh',['network.h',['../network_8h.html',1,'']]],
  ['next',['next',['../struct__gg__chat__list.html#aaed6981b896cae5d37d07a851dd3bdff',1,'_gg_chat_list::next()'],['../struct__gg__msg__list.html#a9ead968b281b37cb8c80ce82e8e55f8e',1,'_gg_msg_list::next()'],['../struct__gg__eventqueue.html#a5ac5c97530b3e852e06b58696d0668a7',1,'_gg_eventqueue::next()'],['../struct__gg__imgout__queue__t.html#a8a72d59318cf103de70e80f94493188a',1,'_gg_imgout_queue_t::next()'],['../structgg__dcc7.html#a2f2ec062fab887d72284ab30bd9ec41b',1,'gg_dcc7::next()'],['../structgg__pubdir50__s.html#a831f9324dcf379fd4ded81f87894c46c',1,'gg_pubdir50_s::next()'],['../structgg__image__queue.html#aadb491cf0bec9e5a5bca558a884fa186',1,'gg_image_queue::next()']]],
  ['next_5fstate',['next_state',['../structgg__state__transition__t.html#a5020013c51d50aa4979933c176fde6fa',1,'gg_state_transition_t']]],
  ['notify',['notify',['../structgg__event__notify__descr.html#aafc17ee564e12a2aef99ddf861b015af',1,'gg_event_notify_descr::notify()'],['../uniongg__event__union.html#aafc17ee564e12a2aef99ddf861b015af',1,'gg_event_union::notify()']]],
  ['notify60',['notify60',['../uniongg__event__union.html#a16e2350e2dc6793a5b4d366f41b1a2aa',1,'gg_event_union']]],
  ['notify_5fdescr',['notify_descr',['../uniongg__event__union.html#ac6b50b4f76ae9cbdff589cde9d3c6825',1,'gg_event_union']]],
  ['num',['num',['../structgg__pubdir50__entry.html#a86cf672daa4e0ad11ad10efc894d19c8',1,'gg_pubdir50_entry']]]
];
