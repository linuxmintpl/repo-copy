var searchData=
[
  ['key',['key',['../structgg__event__user__data__attr.html#a5892a9181e6a332f84d27aecd41dcd12',1,'gg_event_user_data_attr::key()'],['../structgg__welcome.html#a6d4ec8e4f3148d51041635da9986c3fa',1,'gg_welcome::key()']]]
];
