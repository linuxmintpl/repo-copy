var searchData=
[
  ['lista_20błędów',['Lista błędów',['../bug.html',1,'']]],
  ['libgadu',['libgadu',['../index.html',1,'']]],
  ['lista_20rzeczy_20do_20zrobienia',['Lista rzeczy do zrobienia',['../todo.html',1,'']]]
];
