var searchData=
[
  ['połączenia_20bezpośrednie_20między_20klientami',['Połączenia bezpośrednie między klientami',['../group__dcc.html',1,'']]],
  ['połączenia_20bezpośrednie_20do_20wersji_20gadu_2dgadu_206_2ex',['Połączenia bezpośrednie do wersji Gadu-Gadu 6.x',['../group__dcc6.html',1,'']]],
  ['połączenia_20bezpośrednie_20od_20wersji_20gadu_2dgadu_207_2ex',['Połączenia bezpośrednie od wersji Gadu-Gadu 7.x',['../group__dcc7.html',1,'']]],
  ['połączenie_20z_20serwerem',['Połączenie z serwerem',['../group__login.html',1,'']]],
  ['pozostałe_20funkcje',['Pozostałe funkcje',['../group__misc.html',1,'']]],
  ['przypomnienie_20hasła',['Przypomnienie hasła',['../group__remind.html',1,'']]],
  ['połączenie_20z_20serwerem',['Połączenie z serwerem',['../group__session.html',1,'']]]
];
