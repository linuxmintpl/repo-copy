var searchData=
[
  ['brakująca_20funkcjonalność',['Brakująca funkcjonalność',['../group__todo.html',1,'']]]
];
