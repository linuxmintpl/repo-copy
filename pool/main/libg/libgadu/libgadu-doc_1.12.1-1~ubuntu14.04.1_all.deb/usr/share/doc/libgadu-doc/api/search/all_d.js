var searchData=
[
  ['magic',['magic',['../structgg__dcc7__relay__req.html#a57f54349f4fd1cbbb52058812e146af2',1,'gg_dcc7_relay_req::magic()'],['../structgg__dcc7__relay__reply.html#a57f54349f4fd1cbbb52058812e146af2',1,'gg_dcc7_relay_reply::magic()'],['../structgg__dcc7__welcome__server.html#a57f54349f4fd1cbbb52058812e146af2',1,'gg_dcc7_welcome_server::magic()']]],
  ['mainpage_2edox',['mainpage.dox',['../mainpage_8dox.html',1,'']]],
  ['message',['message',['../structgg__event__msg.html#abb13456032cf48eaa794391b6ed937c7',1,'gg_event_msg']]],
  ['message_2ec',['message.c',['../message_8c.html',1,'']]],
  ['message_2eh',['message.h',['../message_8h.html',1,'']]],
  ['messages_2edox',['messages.dox',['../messages_8dox.html',1,'']]],
  ['min_5flength',['min_length',['../structgg__packet__handler__t.html#af12d20ca87aca233534fbbf6a490bbfd',1,'gg_packet_handler_t']]],
  ['mode',['mode',['../structgg__file__info.html#a6b29e4f37f4482274af785ad5ffe96a7',1,'gg_file_info']]],
  ['msg',['msg',['../uniongg__event__union.html#a2f374414717d903a315a819bc56edca5',1,'gg_event_union']]],
  ['msg_5fhdr',['msg_hdr',['../struct__gg__imgout__queue__t.html#ae30de009f580bf27a6ed39418cf296f9',1,'_gg_imgout_queue_t']]],
  ['msg_5ftype',['msg_type',['../structgg__event__ack110.html#af95f620c0e85b634c0caee87127b12a8',1,'gg_event_ack110']]],
  ['msgclass',['msgclass',['../structgg__event__msg.html#a0ceb8275703d4f7e863938f60fdb93f1',1,'gg_event_msg::msgclass()'],['../structgg__send__msg.html#add6332082a3f6241633080da700713d2',1,'gg_send_msg::msgclass()'],['../structgg__recv__msg.html#add6332082a3f6241633080da700713d2',1,'gg_recv_msg::msgclass()'],['../structgg__send__msg80.html#add6332082a3f6241633080da700713d2',1,'gg_send_msg80::msgclass()'],['../structgg__recv__msg80.html#add6332082a3f6241633080da700713d2',1,'gg_recv_msg80::msgclass()']]],
  ['mtime',['mtime',['../structgg__file__info.html#ab127fe9b2ed74e13dba2e2d668c951d9',1,'gg_file_info']]],
  ['multilogon_5finfo',['multilogon_info',['../uniongg__event__union.html#a5a1264be4c34c855235693f83fd9f90b',1,'gg_event_union']]],
  ['multilogon_5fmsg',['multilogon_msg',['../uniongg__event__union.html#ad2c1399744a0170f0fd0f547816306d0',1,'gg_event_union']]]
];
