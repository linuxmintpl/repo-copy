var searchData=
[
  ['prid64',['PRId64',['../internal_8h.html#ae372e90b62c1e8b51dc5d95bf7f5ba48',1,'internal.h']]],
  ['priu64',['PRIu64',['../internal_8h.html#ac582131d7a7c8ee57e73180d1714f9d5',1,'internal.h']]],
  ['prix64',['PRIx64',['../internal_8h.html#aba38357387a474f439428dee1984fc5a',1,'internal.h']]]
];
