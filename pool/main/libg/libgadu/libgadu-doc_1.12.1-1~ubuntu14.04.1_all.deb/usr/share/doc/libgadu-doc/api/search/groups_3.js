var searchData=
[
  ['kompilacja',['Kompilacja',['../group__build.html',1,'']]],
  ['konferencje',['Konferencje',['../group__chat.html',1,'']]],
  ['konfiguracja_20ip',['Konfiguracja IP',['../group__ip.html',1,'']]],
  ['katalog_20publiczny',['Katalog publiczny',['../group__pubdir50.html',1,'']]]
];
