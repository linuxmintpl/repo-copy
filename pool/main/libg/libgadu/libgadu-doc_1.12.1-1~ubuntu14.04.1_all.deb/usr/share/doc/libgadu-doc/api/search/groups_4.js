var searchData=
[
  ['lista_20zmian',['Lista zmian',['../group__changelog.html',1,'']]],
  ['lista_20kontaktów',['Lista kontaktów',['../group__contacts.html',1,'']]]
];
