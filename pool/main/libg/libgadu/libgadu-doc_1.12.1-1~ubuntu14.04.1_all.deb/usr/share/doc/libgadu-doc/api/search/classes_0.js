var searchData=
[
  ['_5fgg_5fchat_5flist',['_gg_chat_list',['../struct__gg__chat__list.html',1,'']]],
  ['_5fgg_5feventqueue',['_gg_eventqueue',['../struct__gg__eventqueue.html',1,'']]],
  ['_5fgg_5fimgout_5fqueue_5ft',['_gg_imgout_queue_t',['../struct__gg__imgout__queue__t.html',1,'']]],
  ['_5fgg_5fmsg_5flist',['_gg_msg_list',['../struct__gg__msg__list.html',1,'']]],
  ['_5fgg_5fprotobuf_5fuin_5fbuff',['_gg_protobuf_uin_buff',['../struct__gg__protobuf__uin__buff.html',1,'']]]
];
