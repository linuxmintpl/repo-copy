var searchData=
[
  ['odpluskwianie',['Odpluskwianie',['../group__debug.html',1,'']]],
  ['obsługa_20zdarzeń',['Obsługa zdarzeń',['../group__events.html',1,'']]]
];
