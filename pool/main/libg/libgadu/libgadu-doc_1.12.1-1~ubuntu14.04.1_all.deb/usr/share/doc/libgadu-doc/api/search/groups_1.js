var searchData=
[
  ['funkcje_20pomocnicze',['Funkcje pomocnicze',['../group__helper.html',1,'']]]
];
