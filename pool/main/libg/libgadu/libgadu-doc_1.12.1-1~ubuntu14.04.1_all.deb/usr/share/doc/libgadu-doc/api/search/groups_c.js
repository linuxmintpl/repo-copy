var searchData=
[
  ['zmiana_20hasła',['Zmiana hasła',['../group__passwd.html',1,'']]],
  ['zmiana_20statusu_20użytkownika',['Zmiana statusu użytkownika',['../group__status.html',1,'']]]
];
