var searchData=
[
  ['fix16',['fix16',['../libgadu_8h.html#a581c34d4fca6aea1e11d93da2923028a',1,'libgadu.h']]],
  ['fix32',['fix32',['../libgadu_8h.html#a3373b9336afb2156a3623e747c976be6',1,'libgadu.h']]]
];
