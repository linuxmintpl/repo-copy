var searchData=
[
  ['gg_5faction_5ft',['gg_action_t',['../events_8c.html#a5529aac97a3faafedfb21c46b5282374',1,'events.c']]],
  ['gg_5fcheck_5ft',['gg_check_t',['../group__events.html#ga6eef74c7cbf152ecd7338667120701db',1,'libgadu.h']]],
  ['gg_5fcompat_5ffeature_5ft',['gg_compat_feature_t',['../internal_8h.html#a089e0f303b4bf018ef4cbed61bb382d4',1,'internal.h']]],
  ['gg_5fcompat_5ft',['gg_compat_t',['../libgadu_8h.html#ab5c01d6dec4f4ea4d33f5357f2e1046e',1,'libgadu.h']]],
  ['gg_5fencoding_5ft',['gg_encoding_t',['../libgadu_8h.html#adbaace4dc70e6607a9d6bd4c23cd2498',1,'libgadu.h']]],
  ['gg_5ferror_5ft',['gg_error_t',['../libgadu_8h.html#a8a7800a03f87e95ca36303f0cdf0d163',1,'libgadu.h']]],
  ['gg_5fevent_5ft',['gg_event_t',['../group__events.html#ga3dd02c0d2ff1d304d134f677faf66cfc',1,'libgadu.h']]],
  ['gg_5ffailure_5ft',['gg_failure_t',['../libgadu_8h.html#a0228f2f274fa5d3d1626b8f1742d9433',1,'libgadu.h']]],
  ['gg_5flibgadu_5ffeature_5ft',['gg_libgadu_feature_t',['../group__version.html#gac4777982c5734d69b512cbfc950a9186',1,'libgadu.h']]],
  ['gg_5fpubdir_5ferror_5ft',['gg_pubdir_error_t',['../group__http.html#ga9dbcf23828ccbab06c656e809263931d',1,'libgadu.h']]],
  ['gg_5fresolver_5ft',['gg_resolver_t',['../libgadu_8h.html#a7bb365d8dbaef300a442a8a29adca931',1,'libgadu.h']]],
  ['gg_5fsession_5ft',['gg_session_t',['../libgadu_8h.html#a8e0ba81bce6c15f3538fde299ba640e0',1,'libgadu.h']]],
  ['gg_5fsocket_5fmanager_5ftype_5ft',['gg_socket_manager_type_t',['../group__socketmanager.html#ga7e531710a578f880b8c354ff4e622491',1,'libgadu.h']]],
  ['gg_5fssl_5ft',['gg_ssl_t',['../group__login.html#gaf5331c4041f0322580d80922d59d0594',1,'libgadu.h']]],
  ['gg_5fstate_5ft',['gg_state_t',['../libgadu_8h.html#afbb1b72a09ced0851effa5e75b31a6a7',1,'libgadu.h']]]
];
