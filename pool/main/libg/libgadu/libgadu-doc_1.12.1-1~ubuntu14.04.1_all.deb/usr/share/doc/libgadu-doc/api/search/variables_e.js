var searchData=
[
  ['offset',['offset',['../structgg__tvbuff.html#aadb6d6eb83e646653a1402032e45dcab',1,'gg_tvbuff::offset()'],['../structgg__dcc.html#a29b5297d3393519050e3126c4cb07c1c',1,'gg_dcc::offset()'],['../structgg__dcc7.html#a29b5297d3393519050e3126c4cb07c1c',1,'gg_dcc7::offset()'],['../structgg__dcc7__accept.html#a894bdfa2d603d8343f8ef01dda6fcd23',1,'gg_dcc7_accept::offset()']]],
  ['offset_5fattr',['offset_attr',['../structgg__send__msg80.html#a78ed1fc93c1c33e624fc289d06cacb04',1,'gg_send_msg80::offset_attr()'],['../structgg__recv__msg80.html#a78ed1fc93c1c33e624fc289d06cacb04',1,'gg_recv_msg80::offset_attr()']]],
  ['offset_5fplain',['offset_plain',['../structgg__send__msg80.html#a4b191e5444fd7c7d1aced25b15981e75',1,'gg_send_msg80::offset_plain()'],['../structgg__recv__msg80.html#a4b191e5444fd7c7d1aced25b15981e75',1,'gg_recv_msg80::offset_plain()']]]
];
