var searchData=
[
  ['lista_20błędów',['Lista błędów',['../bug.html',1,'']]],
  ['lista_20zmian',['Lista zmian',['../group__changelog.html',1,'']]],
  ['lista_20kontaktów',['Lista kontaktów',['../group__contacts.html',1,'']]],
  ['libgadu',['libgadu',['../index.html',1,'']]],
  ['language',['language',['../structgg__login80.html#a8ca6c1b2fce3085120dd9a1abb5ff3aa',1,'gg_login80']]],
  ['last_5fevent',['last_event',['../structgg__session.html#a876114e3daba9dee2ec31aa34cf431a2',1,'gg_session']]],
  ['last_5fpong',['last_pong',['../structgg__session.html#a00f01e97a7704d8a56068f0512203910',1,'gg_session']]],
  ['last_5fsysmsg',['last_sysmsg',['../structgg__session.html#afb0337a48a614cc3a06d794b20b976fe',1,'gg_session::last_sysmsg()'],['../structgg__login__params.html#afb0337a48a614cc3a06d794b20b976fe',1,'gg_login_params::last_sysmsg()']]],
  ['len',['len',['../structgg__dcc7__voice__data.html#a96bbf959016e4411c9e6b9812a8be60a',1,'gg_dcc7_voice_data::len()'],['../structgg__dcc7__voice__init.html#a96bbf959016e4411c9e6b9812a8be60a',1,'gg_dcc7_voice_init::len()'],['../structgg__dcc7__relay__req.html#a96bbf959016e4411c9e6b9812a8be60a',1,'gg_dcc7_relay_req::len()'],['../structgg__dcc7__relay__reply.html#a96bbf959016e4411c9e6b9812a8be60a',1,'gg_dcc7_relay_reply::len()']]],
  ['length',['length',['../structgg__tvbuff.html#ae809d5359ac030c60a30a8f0b2294b82',1,'gg_tvbuff::length()'],['../structgg__tvbuilder.html#ae809d5359ac030c60a30a8f0b2294b82',1,'gg_tvbuilder::length()'],['../structgg__event__dcc__voice__data.html#a9f59b34b1f25fe00023291b678246bcc',1,'gg_event_dcc_voice_data::length()'],['../structgg__event__typing__notification.html#a9f59b34b1f25fe00023291b678246bcc',1,'gg_event_typing_notification::length()'],['../structgg__token.html#a9f59b34b1f25fe00023291b678246bcc',1,'gg_token::length()'],['../structgg__header.html#aebb70c2aab3407a9f05334c47131a43b',1,'gg_header::length()'],['../structgg__msg__richtext.html#a1892eba2086d12ac2b09005aeb09ea3b',1,'gg_msg_richtext::length()'],['../structgg__typing__notification.html#a1892eba2086d12ac2b09005aeb09ea3b',1,'gg_typing_notification::length()']]],
  ['libgadu_2ec',['libgadu.c',['../libgadu_8c.html',1,'']]],
  ['libgadu_2eh',['libgadu.h',['../libgadu_8h.html',1,'']]],
  ['local_5faddr',['local_addr',['../structgg__dcc7.html#a165d0e6ea9679c6a440ecefd7497744f',1,'gg_dcc7']]],
  ['local_5fip',['local_ip',['../structgg__login.html#ad13ce3035d3994a78b999f50ec56dccc',1,'gg_login::local_ip()'],['../structgg__login__ext.html#ad13ce3035d3994a78b999f50ec56dccc',1,'gg_login_ext::local_ip()'],['../structgg__login60.html#ad13ce3035d3994a78b999f50ec56dccc',1,'gg_login60::local_ip()'],['../structgg__login70.html#ad13ce3035d3994a78b999f50ec56dccc',1,'gg_login70::local_ip()'],['../structgg__login80.html#ad13ce3035d3994a78b999f50ec56dccc',1,'gg_login80::local_ip()']]],
  ['local_5fport',['local_port',['../structgg__dcc7.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_dcc7::local_port()'],['../structgg__login.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_login::local_port()'],['../structgg__login__ext.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_login_ext::local_port()'],['../structgg__login60.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_login60::local_port()'],['../structgg__login70.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_login70::local_port()'],['../structgg__login80.html#a7c8171cd15cb1f99e0a352fef95750e3',1,'gg_login80::local_port()']]],
  ['login_2edox',['login.dox',['../login_8dox.html',1,'']]],
  ['logon_5ftime',['logon_time',['../structgg__multilogon__session.html#a6007285d64f47f1f52645f832eaa553a',1,'gg_multilogon_session::logon_time()'],['../structgg__multilogon__info__item.html#a7bde24b04cca822ac4e58eab4dab6266',1,'gg_multilogon_info_item::logon_time()']]],
  ['lista_20rzeczy_20do_20zrobienia',['Lista rzeczy do zrobienia',['../todo.html',1,'']]]
];
