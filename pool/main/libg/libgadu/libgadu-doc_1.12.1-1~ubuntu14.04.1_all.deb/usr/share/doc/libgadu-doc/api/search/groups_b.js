var searchData=
[
  ['wiadomości',['Wiadomości',['../group__messages.html',1,'']]],
  ['własne_20funkcje_20do_20nawiązywania_20połączeń_20tcp_2ftls',['Własne funkcje do nawiązywania połączeń TCP/TLS',['../group__socketmanager.html',1,'']]]
];
