var searchData=
[
  ['import_20i_20eksport_20listy_20kontaktów',['Import i eksport listy kontaktów',['../group__importexport.html',1,'']]],
  ['informacje_20o_20bibliotece',['Informacje o bibliotece',['../group__version.html',1,'']]]
];
