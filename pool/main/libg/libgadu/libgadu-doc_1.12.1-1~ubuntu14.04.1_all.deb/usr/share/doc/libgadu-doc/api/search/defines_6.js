var searchData=
[
  ['s_5fiwusr',['S_IWUSR',['../fileio_8h.html#ad70001754261c15a1bdc8e876c6d09d7',1,'fileio.h']]]
];
