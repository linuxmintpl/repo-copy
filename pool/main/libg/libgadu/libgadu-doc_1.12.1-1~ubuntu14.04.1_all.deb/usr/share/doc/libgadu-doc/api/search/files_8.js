var searchData=
[
  ['libgadu_2ec',['libgadu.c',['../libgadu_8c.html',1,'']]],
  ['libgadu_2eh',['libgadu.h',['../libgadu_8h.html',1,'']]],
  ['login_2edox',['login.dox',['../login_8dox.html',1,'']]]
];
