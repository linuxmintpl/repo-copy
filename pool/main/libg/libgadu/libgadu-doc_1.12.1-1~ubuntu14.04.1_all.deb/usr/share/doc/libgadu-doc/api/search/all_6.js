var searchData=
[
  ['failure',['failure',['../uniongg__event__union.html#a699efbf5c2bd5e6014feb55e10ae1d5e',1,'gg_event_union']]],
  ['family',['family',['../structgg__dcc7__relay.html#adad4493a852deb413bb8c515368deaac',1,'gg_dcc7_relay::family()'],['../structgg__dcc7__relay__reply__server.html#adad4493a852deb413bb8c515368deaac',1,'gg_dcc7_relay_reply_server::family()']]],
  ['fd',['fd',['../structgg__common.html#a6f8059414f0228f0256115e024eeed4b',1,'gg_common::fd()'],['../structgg__session.html#a6f8059414f0228f0256115e024eeed4b',1,'gg_session::fd()'],['../structgg__http.html#a6f8059414f0228f0256115e024eeed4b',1,'gg_http::fd()'],['../structgg__dcc.html#a6f8059414f0228f0256115e024eeed4b',1,'gg_dcc::fd()'],['../structgg__dcc7.html#a6f8059414f0228f0256115e024eeed4b',1,'gg_dcc7::fd()']]],
  ['fd_5fafter_5fqueue',['fd_after_queue',['../structgg__session__private.html#ae414c0fa559f4f624eed9eba73ebc3cc',1,'gg_session_private']]],
  ['features',['features',['../structgg__login80.html#a12ba3859f1e3503c94df8e7f6ef711eb',1,'gg_login80::features()'],['../structgg__notify__reply80.html#a12ba3859f1e3503c94df8e7f6ef711eb',1,'gg_notify_reply80::features()'],['../structgg__multilogon__info__item.html#a12ba3859f1e3503c94df8e7f6ef711eb',1,'gg_multilogon_info_item::features()']]],
  ['field',['field',['../structgg__pubdir50__entry.html#a9dc45f3ba68f8623d182e7c4b451d443',1,'gg_pubdir50_entry']]],
  ['file_5ffd',['file_fd',['../structgg__dcc.html#a2200c35a6b214e89508d43377f4483ca',1,'gg_dcc::file_fd()'],['../structgg__dcc7.html#a2200c35a6b214e89508d43377f4483ca',1,'gg_dcc7::file_fd()']]],
  ['file_5finfo',['file_info',['../structgg__dcc.html#a85a9f5a9ce4394bf495bced3756f2e66',1,'gg_dcc']]],
  ['fileio_2eh',['fileio.h',['../fileio_8h.html',1,'']]],
  ['filename',['filename',['../structgg__file__info.html#afe068ec9a196dca8cccf70ba366169e6',1,'gg_file_info::filename()'],['../structgg__dcc7.html#a62d40a4a10013d8154862d1c515f5d7a',1,'gg_dcc7::filename()'],['../structgg__event__image__reply.html#aeac90097f29f7529968697163cea5c18',1,'gg_event_image_reply::filename()'],['../structgg__image__queue.html#aeac90097f29f7529968697163cea5c18',1,'gg_image_queue::filename()'],['../structgg__dcc7__new.html#ae44642c5ec4e1de97c4a7cdb3fa87bc7',1,'gg_dcc7_new::filename()']]],
  ['fix16',['fix16',['../libgadu_8h.html#a581c34d4fca6aea1e11d93da2923028a',1,'libgadu.h']]],
  ['fix32',['fix32',['../libgadu_8h.html#a3373b9336afb2156a3623e747c976be6',1,'libgadu.h']]],
  ['flag',['flag',['../structgg__msg__richtext.html#aff31312fb16705aa73c53b945a1a6b30',1,'gg_msg_richtext::flag()'],['../structgg__msg__recipients.html#aff31312fb16705aa73c53b945a1a6b30',1,'gg_msg_recipients::flag()'],['../structgg__msg__image__request.html#aff31312fb16705aa73c53b945a1a6b30',1,'gg_msg_image_request::flag()'],['../structgg__msg__image__reply.html#aff31312fb16705aa73c53b945a1a6b30',1,'gg_msg_image_reply::flag()']]],
  ['flags',['flags',['../structgg__event__msg.html#a899a76dc5f03f0d4ea3793c339e07ee9',1,'gg_event_msg::flags()'],['../structgg__login80.html#a773b39d480759f67926cb18ae2219281',1,'gg_login80::flags()'],['../structgg__new__status80.html#a773b39d480759f67926cb18ae2219281',1,'gg_new_status80::flags()'],['../structgg__notify__reply80.html#a773b39d480759f67926cb18ae2219281',1,'gg_notify_reply80::flags()'],['../structgg__multilogon__info__item.html#a773b39d480759f67926cb18ae2219281',1,'gg_multilogon_info_item::flags()']]],
  ['font',['font',['../structgg__msg__richtext__format.html#adeae49dfe3584e6df726fb4167cd1cf7',1,'gg_msg_richtext_format']]],
  ['format_5ftype',['format_type',['../structgg__event__userlist100__reply.html#a63276011d84ce2ce46d2890b04113a67',1,'gg_event_userlist100_reply::format_type()'],['../structgg__userlist100__request.html#a18d3d5876596b20126cec36a4226c1a8',1,'gg_userlist100_request::format_type()'],['../structgg__userlist100__reply.html#a18d3d5876596b20126cec36a4226c1a8',1,'gg_userlist100_reply::format_type()']]],
  ['formats',['formats',['../structgg__event__msg.html#ae83dd485aa919b232857cabccaed2994',1,'gg_event_msg']]],
  ['formats_5flength',['formats_length',['../structgg__event__msg.html#a010498a94dfab5211b6327c57178e38f',1,'gg_event_msg']]],
  ['funkcje_20pomocnicze',['Funkcje pomocnicze',['../group__helper.html',1,'']]]
];
