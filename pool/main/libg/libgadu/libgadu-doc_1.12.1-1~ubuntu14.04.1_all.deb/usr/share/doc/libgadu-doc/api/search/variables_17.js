var searchData=
[
  ['xhtml_5fmessage',['xhtml_message',['../structgg__event__msg.html#a520bd874cebe3f03920f78c61e0deb0e',1,'gg_event_msg']]],
  ['xml_5fevent',['xml_event',['../uniongg__event__union.html#a1263c0c751577a320b6104a6c48ec185',1,'gg_event_union']]]
];
