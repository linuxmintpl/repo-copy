var searchData=
[
  ['kompilacja',['Kompilacja',['../group__build.html',1,'']]],
  ['konferencje',['Konferencje',['../group__chat.html',1,'']]],
  ['konfiguracja_20ip',['Konfiguracja IP',['../group__ip.html',1,'']]],
  ['key',['key',['../structgg__event__user__data__attr.html#a5892a9181e6a332f84d27aecd41dcd12',1,'gg_event_user_data_attr::key()'],['../structgg__welcome.html#a6d4ec8e4f3148d51041635da9986c3fa',1,'gg_welcome::key()']]],
  ['katalog_20publiczny',['Katalog publiczny',['../group__pubdir50.html',1,'']]]
];
