This is a chat style for Kadu Instant Messenger ( http://www.kadu.im/ )
Theme maintainer: KaduTeam

If you have any questions ask maintainer directly or ask on http://www.kadu.im/forum/
  
SimpleStuff chat style is licensed under the GNU General Public License (please see 'License' file). Oryginaly made for Adium instant messenger (http://adium.im/) by Grant Colley ( harouka  _!at!_  gmail dot com )
