This is a chat style for Kadu Instant Messenger ( http://www.kadu.im/ )
Theme maintainer: KaduTeam

If you have any questions ask maintainer directly or ask on http://www.kadu.im/forum/
  
Modern Bubbling chat style is licensed under the MIT license (please see 'License' file). Oryginaly made for Adium instant messenger (http://adium.im/) by Jim Myhrberg ( contact _!at!_ jimeh dot me 
