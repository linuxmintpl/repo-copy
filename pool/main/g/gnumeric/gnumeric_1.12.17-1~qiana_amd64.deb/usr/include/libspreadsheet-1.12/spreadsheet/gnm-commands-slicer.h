/* vim: set sw=8: -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef _GNM_COMMANDS_SLICER_H
# define _GNM_COMMANDS_SLICER_H

#include "gnumeric.h"

gboolean cmd_slicer_refresh (WorkbookControl *wbc);

#endif /* _GNM_COMMANDS_SLICER_H */
