/* vim: set sw=8: -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef _GNM_RANGEFUNC_STRINGS_H_
# define _GNM_RANGEFUNC_STRINGS_H_

#include "numbers.h"

G_BEGIN_DECLS

int range_concatenate (GPtrArray *data, char **res);

G_END_DECLS

#endif /* _GNM_RANGEFUNC_STRINGS_H_ */
