/* vim: set sw=8: -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef _GNM_HISTORY_H_
# define _GNM_HISTORY_H_

#include "gnumeric.h"

G_BEGIN_DECLS

char *history_item_label (char const *uri, int accel_number);

G_END_DECLS

#endif /* _GNM_HISTORY_H_ */
