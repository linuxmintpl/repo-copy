#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 4
#define VBOX_VERSION_MINOR 3
#define VBOX_VERSION_BUILD 14
#define VBOX_VERSION_STRING_RAW "4.3.14"
#define VBOX_VERSION_STRING "4.3.14_Ubuntu"
#define VBOX_API_VERSION_STRING "4_3"

#endif
