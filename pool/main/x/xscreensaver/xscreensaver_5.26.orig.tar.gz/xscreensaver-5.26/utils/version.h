static const char screensaver_id[] =
	"@(#)xscreensaver 5.26 (09-Dec-2013), by Jamie Zawinski (jwz@jwz.org)";
