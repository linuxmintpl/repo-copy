<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl_PL">
<context>
    <name>BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="35"/>
        <source>&amp;Open</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="40"/>
        <source>Open in new &amp;tab</source>
        <translation>Otwórz w nowej &amp;karcie</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="50"/>
        <source>&amp;Remove bookmark</source>
        <translation>&amp;Usuń zakładkę</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="72"/>
        <source>Jump to page %1</source>
        <translation>Skocz do strony %1</translation>
    </message>
</context>
<context>
    <name>DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="219"/>
        <source>Supported formats (%1)</source>
        <translation>Wspierane formaty (%1)</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Unlock %1</source>
        <translation>Odblokuj %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Information</source>
        <translation>Informacje</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation>Otwieranie adresów URL jest wyłączone w ustawieniach.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation>Dane systemu SyncTeX dla &apos;%1&apos; nie zostały znalezione.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1495"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation>Drukowanie &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1641"/>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation>Nie można otworzyć &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="884"/>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="900"/>
        <source>Open in new tab</source>
        <translation>Otwórz w nowej karcie</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation>Nie można odświeżyć &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="929"/>
        <source>Save copy</source>
        <translation>Zapisz kopię</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation>Nie można zapisać kopii jako &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="946"/>
        <source>Save as</source>
        <translation>Zapisz jako</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation>Nie można zapisać jako &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation>Nie można wydrukować &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Jump to page</source>
        <translation>Skocz do strony</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Page:</source>
        <translation>Strona:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>About qpdfview</source>
        <translation>O programie qpdfview</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview to przeglądarka dokumentów z kartami używająca interfejsu Qt.&lt;/p&gt;&lt;p&gt;Ta wersja zawiera:&lt;ul&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1496"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <translation>&lt;li&gt;Obsługa formatu PDF za pomocą Poppler&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1499"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <translation>&lt;li&gt;Wsparcie PS przy użyciu libspectre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1502"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <translation>&lt;li&gt;Wsparcie DjVu przy użyciu DjVuLibre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1505"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <translation>&lt;li&gt;Drukowanie wspieranie przez użyciu CUPS&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1507"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 The qpdfview developers&lt;/p&gt;</source>
        <translation>&lt;/ul&gt;&lt;p&gt;Zobacz &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; po więcej informacji.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 Autorzy qpdfview&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1714"/>
        <source>Page width</source>
        <translation>Szerokość strony</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1715"/>
        <source>Page size</source>
        <translation>Rozmiar strony</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1736"/>
        <source>Match &amp;case</source>
        <translation>Uwzględniaj &amp;wielkość liter</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1737"/>
        <source>Highlight &amp;all</source>
        <translation>Podświetl &amp;wszystko</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1781"/>
        <source>&amp;Open...</source>
        <translation>&amp;Otwórz...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1782"/>
        <source>Open in new &amp;tab...</source>
        <translation>Otwórz w nowej &amp;karcie...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1783"/>
        <source>&amp;Refresh</source>
        <translation>O&amp;dśwież</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1784"/>
        <source>&amp;Save copy...</source>
        <translation>&amp;Zapisz kopię...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1785"/>
        <source>Save &amp;as...</source>
        <translation>Zapisz &amp;jako...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1786"/>
        <source>&amp;Print...</source>
        <translation>&amp;Drukuj...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1787"/>
        <source>E&amp;xit</source>
        <translation>Zakoń&amp;cz</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1791"/>
        <source>&amp;Previous page</source>
        <translation>Pop&amp;rzednia strona</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1792"/>
        <source>&amp;Next page</source>
        <translation>&amp;Następna strona</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1793"/>
        <source>&amp;First page</source>
        <translation>&amp;Pierwsza strona</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1794"/>
        <source>&amp;Last page</source>
        <translation>&amp;Ostatnia strona</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1796"/>
        <source>&amp;Jump to page...</source>
        <translation>&amp;Skocz do strony...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1798"/>
        <source>Jump &amp;backward</source>
        <translation>Przejdź &amp;do tyłu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1799"/>
        <source>Jump for&amp;ward</source>
        <translation>Przejdź do p&amp;rzodu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1801"/>
        <source>&amp;Search...</source>
        <translation>&amp;Znajdź...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1802"/>
        <source>Find previous</source>
        <translation>Znajdź poprzedni</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1803"/>
        <source>Find next</source>
        <translation>Znajdź następny</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1804"/>
        <source>Cancel search</source>
        <translation>Anuluj wyszukiwanie</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1806"/>
        <source>&amp;Copy to clipboard</source>
        <translation>&amp;Kopiuj do schowka</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1807"/>
        <source>&amp;Add annotation</source>
        <translation>&amp;Dodaj adnotację</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1809"/>
        <source>Settings...</source>
        <translation>Ustawienia...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1813"/>
        <source>&amp;Continuous</source>
        <translation>Widok &amp;ciągły</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1814"/>
        <source>&amp;Two pages</source>
        <translation>&amp;Dwie strony</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1815"/>
        <source>Two pages &amp;with cover page</source>
        <translation>Dwie strony z &amp;okładką</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1816"/>
        <source>&amp;Multiple pages</source>
        <translation>&amp;Wiele stron</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1818"/>
        <source>Zoom &amp;in</source>
        <translation>&amp;Powiększ</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1819"/>
        <source>Zoom &amp;out</source>
        <translation>Po&amp;mniejsz</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1820"/>
        <source>Original &amp;size</source>
        <translation>Wielkość &amp;oryginalna</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1822"/>
        <source>Fit to page width</source>
        <translation>Dostosuj do szerokości</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1823"/>
        <source>Fit to page size</source>
        <translation>Dostosuj do wielkości</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1825"/>
        <source>Rotate &amp;left</source>
        <translation>Obróć w &amp;lewo</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1826"/>
        <source>Rotate &amp;right</source>
        <translation>Obróć w &amp;prawo</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1828"/>
        <source>Invert colors</source>
        <translation>Odwróć kolory</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1830"/>
        <source>Fonts...</source>
        <translation>Czcionki...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1832"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Pełny ekran</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1833"/>
        <source>&amp;Presentation...</source>
        <translation>Pre&amp;zentacja...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1837"/>
        <source>&amp;Previous tab</source>
        <translation>&amp;Poprzednia karta</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1838"/>
        <source>&amp;Next tab</source>
        <translation>&amp;Następna karta</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1840"/>
        <source>&amp;Close tab</source>
        <translation>&amp;Zamknij kartę</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1841"/>
        <source>Close &amp;all tabs</source>
        <translation>Zamknij &amp;wszystkie karty</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1842"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation>Zamknij &amp;pozostałe karty</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1853"/>
        <source>&amp;Previous bookmark</source>
        <translation>&amp;Poprzednia zakładka</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1854"/>
        <source>&amp;Next bookmark</source>
        <translation>&amp;Następna zakładka</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1856"/>
        <source>&amp;Add bookmark</source>
        <translation>&amp;Dodaj zakładkę</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1857"/>
        <source>&amp;Remove bookmark</source>
        <translation>&amp;Usuń zakładkę</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1858"/>
        <source>Remove all bookmarks</source>
        <translation>Usuń wszystkie zakładki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1862"/>
        <source>&amp;Contents</source>
        <translation>&amp;Spis streści</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1863"/>
        <source>&amp;About</source>
        <translation>&amp;O progamie</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1897"/>
        <location filename="../sources/mainwindow.cpp" line="2011"/>
        <source>&amp;File</source>
        <translation>&amp;Plik</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1900"/>
        <location filename="../sources/mainwindow.cpp" line="2046"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edycja</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1903"/>
        <location filename="../sources/mainwindow.cpp" line="2059"/>
        <source>&amp;View</source>
        <translation>&amp;Widok</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1964"/>
        <source>&amp;Search</source>
        <translation>&amp;Wyszukaj</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1929"/>
        <source>&amp;Outline</source>
        <translation>&amp;Konspekt</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1942"/>
        <source>&amp;Properties</source>
        <translation>&amp;Właściwości</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1952"/>
        <source>&amp;Thumbnails</source>
        <translation>&amp;Miniatury</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2069"/>
        <source>&amp;Tool bars</source>
        <translation>Paski &amp;narzędzi</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2072"/>
        <source>&amp;Docks</source>
        <translation>&amp;Widoki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2081"/>
        <source>&amp;Tabs</source>
        <translation>&amp;Karty</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2089"/>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Zakładki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2097"/>
        <source>&amp;Help</source>
        <translation>P&amp;omoc</translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Type</source>
        <translation>Rodzaj</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Embedded</source>
        <translation>Osadzony</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Subset</source>
        <translation>Podzbiór</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>No</source>
        <translation>Nie</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation>Wersja 0.20.1 lub wyższa biblioteki Poppler jest wymagana by dodawać lub  usuwać adnotacje.</translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Created for</source>
        <translation>Utworzono dla</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creator</source>
        <translation>Utworzył</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Creation date</source>
        <translation>Data utworzenia</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="222"/>
        <source>Language level</source>
        <translation>Poziom języka</translation>
    </message>
</context>
<context>
    <name>PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="333"/>
        <source>Go to page %1.</source>
        <translation>Skocz do strony %1.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="337"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation>Przejdź do strony %1 pliku &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="345"/>
        <source>Open &apos;%1&apos;.</source>
        <translation>Otwórz &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="380"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation>Edytuj pole formularza &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="596"/>
        <source>Copy &amp;text</source>
        <translation>Kopiuj &amp;tekst</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="597"/>
        <source>Copy &amp;image</source>
        <translation>Kopiuj &amp;obraz</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="598"/>
        <source>Save image to &amp;file...</source>
        <translation>Zapisz obraz do &amp;pliku...</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="624"/>
        <source>Save image to file</source>
        <translation>Zapisz obraz do pliku</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation>Nie można zapisać obrazu do pliku &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="641"/>
        <source>Add &amp;text</source>
        <translation>Dodaj &amp;tekst</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="642"/>
        <source>Add &amp;highlight</source>
        <translation>Dodaj po&amp;dświetlenie</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="679"/>
        <source>&amp;Remove annotation</source>
        <translation>&amp;Usuń adnotację</translation>
    </message>
</context>
<context>
    <name>PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="804"/>
        <source>Antialiasing:</source>
        <translation>Antyaliasing:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="811"/>
        <source>Text antialiasing:</source>
        <translation>Antyaliasing tekstu:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <location filename="../sources/pdfmodel.cpp" line="848"/>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="819"/>
        <source>Full</source>
        <translation>Pełny</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="820"/>
        <source>Reduced</source>
        <translation>Zredukowano</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="823"/>
        <location filename="../sources/pdfmodel.cpp" line="830"/>
        <source>Text hinting:</source>
        <translation>Tekst podpowiedzi:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="841"/>
        <source>Overprint preview:</source>
        <translation>Podgląd wydruku:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="849"/>
        <source>Solid</source>
        <translation>Jednolity</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="850"/>
        <source>Shaped</source>
        <translation>Uformowane</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="853"/>
        <source>Thin line mode:</source>
        <translation>Tryb cienkiej linii:</translation>
    </message>
</context>
<context>
    <name>PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Critical</source>
        <translation>Krytyczny</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <source>Could not load PDF plug-in!</source>
        <translation>Nie można wczytać wtyczki PDF!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <source>Could not load PS plug-in!</source>
        <translation>Nie można wczytać wtyczki PS!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Could not load DjVu plug-in!</source>
        <translation>Nie można wczytać wtyczki DjVu!</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <translation>Dopasuj do strony:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <translation>Zakres stron:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <translation>Wszystkie strony</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <translation>Parzyste strony</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <translation>Nieparzyste strony</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <translation>Wybór stron:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <translation>Pojedyncza strona</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <translation>Dwie strony</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <translation>Cztery strony</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <translation>Sześć stron</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <translation>Dziewięć stron</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <translation>Szesnaście stron</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <translation>Stron na arkusz:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <translation>Od dołu do góry i od lewej do prawej</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <translation>Od dołu do góry i od prawej do lewej</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <translation>Od lewej do prawej i od dołu do góry</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <translation>Od lewej do prawej i od góry do dołu</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <translation>Od prawej do lewej i od dołu do góry</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <translation>Od prawej do lewej i od góry do dołu</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <translation>Od góry do dołu i od lewej do prawej</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <translation>Od góry do dołu i od prawej do lewej</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <translation>Kolejność:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <translation>Opcje rozszerzone</translation>
    </message>
</context>
<context>
    <name>PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="236"/>
        <source>Graphics antialias bits:</source>
        <translation>Antyaliasing grafiki:</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Text antialias bits:</source>
        <translation>Antyaliasing tekstu:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="127"/>
        <source>An empty instance name is not allowed.</source>
        <translation>Pusta nazwa instancji nie jest dozwolona.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="138"/>
        <source>An empty search text is not allowed.</source>
        <translation>Wyszukiwanie pustego tekstu jest niedozwolone.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="203"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation>Użycie opcji &apos;--instance&apos; wymaga podania nazwy.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="209"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation>Użycie opcji &apos;--instance&apos; nie jest dozwolone bez opcji &apos;--unique&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="215"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation>Użycie &apos;--search&apos; wymaga podania szukanego tekstu.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="258"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation>Dane systemu SyncTeX dla &apos;%1&apos; nie zostały znalezione.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="353"/>
        <source>Could not prepare signal handler.</source>
        <translation>Nie można przygotować obsługi sygnału.</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="714"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="715"/>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="716"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="717"/>
        <source>Shift and Ctrl</source>
        <translation>Shift i Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="718"/>
        <source>Shift and Alt</source>
        <translation>Shift i Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="719"/>
        <source>Ctrl and Alt</source>
        <translation>Ctrl i Alt</translation>
    </message>
</context>
<context>
    <name>RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="29"/>
        <source>Recently &amp;used</source>
        <translation>Ostatnio &amp;użyte</translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="38"/>
        <source>&amp;Clear list</source>
        <translation>&amp;Wyczyść listę</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="54"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="105"/>
        <source>&amp;Behavior</source>
        <translation>&amp;Zachowanie</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="106"/>
        <source>&amp;Graphics</source>
        <translation>&amp;Wyświetlanie</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="107"/>
        <source>&amp;Interface</source>
        <translation>&amp;Interfejs</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="108"/>
        <source>&amp;Shortcuts</source>
        <translation>&amp;Skróty</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="109"/>
        <source>&amp;Modifiers</source>
        <translation>&amp;Klawisze</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="115"/>
        <source>Defaults</source>
        <translation>Domyślne</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="280"/>
        <source>Open URL:</source>
        <translation>Otwieraj URL-e:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="287"/>
        <source>Auto-refresh:</source>
        <translation>Autoodświeżanie:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="293"/>
        <location filename="../sources/settingsdialog.cpp" line="590"/>
        <location filename="../sources/settingsdialog.cpp" line="598"/>
        <location filename="../sources/settingsdialog.cpp" line="606"/>
        <location filename="../sources/settingsdialog.cpp" line="614"/>
        <source>Effective after restart.</source>
        <translation>Zmiany dostępne po ponownym uruchomieniu.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="295"/>
        <source>Track recently used:</source>
        <translation>Śledź ostatnio użyte:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="302"/>
        <source>Restore tabs:</source>
        <translation>Przywróć karty:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="309"/>
        <source>Restore bookmarks:</source>
        <translation>Przywróć zakładki:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="316"/>
        <source>Restore per-file settings:</source>
        <translation>Przywróć ustawienia dla plików:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="331"/>
        <source>Synchronize presentation:</source>
        <translation>Synchronizuj prezentację:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="337"/>
        <source>Default</source>
        <translation>Domyślny</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="340"/>
        <source>Presentation screen:</source>
        <translation>Ekran do prezentacji:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="371"/>
        <source>Annotation color:</source>
        <translation>Kolor adnotacji:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="377"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation>sekwencja &apos;%1&apos; jest zastępowana przez ścieżkę bezwzględną. &apos;%2&apos; i &apos;%3&apos; są zastępowane odpowiednio przez numer linii i kolumny.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="379"/>
        <source>Source editor:</source>
        <translation>Edytor tekstu źródłowego:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="411"/>
        <source>Decorate pages:</source>
        <translation>Dekoracje stron:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="418"/>
        <source>Decorate links:</source>
        <translation>Dekoracje linków:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="425"/>
        <source>Decorate form fields:</source>
        <translation>Dekoracje pól formularza:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="358"/>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="118"/>
        <source>Defaults on current tab</source>
        <translation>Domyślne na bieżącej karcie</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="350"/>
        <source>Highlight color:</source>
        <translation>Kolor podświetlenia:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="361"/>
        <source>Highlight duration:</source>
        <translation>Czas trwania podświetlenia:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="435"/>
        <source>Background color:</source>
        <translation>Kolor tła:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="445"/>
        <source>Paper color:</source>
        <translation>Kolor papieru:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="453"/>
        <source>Pages per row:</source>
        <translation>Stron w wierszu:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="463"/>
        <source>Page spacing:</source>
        <translation>Odstępy między stronami:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="473"/>
        <source>Thumbnail spacing:</source>
        <translation>Odstępy między miniaturami:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="483"/>
        <source>Thumbnail size:</source>
        <translation>Wielkość miniatury:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="488"/>
        <location filename="../sources/settingsdialog.cpp" line="489"/>
        <location filename="../sources/settingsdialog.cpp" line="490"/>
        <location filename="../sources/settingsdialog.cpp" line="491"/>
        <location filename="../sources/settingsdialog.cpp" line="492"/>
        <location filename="../sources/settingsdialog.cpp" line="493"/>
        <location filename="../sources/settingsdialog.cpp" line="494"/>
        <location filename="../sources/settingsdialog.cpp" line="495"/>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="498"/>
        <source>Cache size:</source>
        <translation>Wielkość bufora:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="505"/>
        <source>Prefetch:</source>
        <translation>Ładowanie z wyprzedzeniem:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="513"/>
        <source>Prefetch distance:</source>
        <translation>Dystans wyprzedzenia:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="560"/>
        <source>Top</source>
        <translation>Na górze</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="561"/>
        <source>Bottom</source>
        <translation>Na dole</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="562"/>
        <source>Left</source>
        <translation>Po lewej</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="563"/>
        <source>Right</source>
        <translation>Po prawej</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="566"/>
        <source>Tab position:</source>
        <translation>Położenie paska kart:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="571"/>
        <source>As needed</source>
        <translation>Gdy konieczne</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="572"/>
        <source>Always</source>
        <translation>Zawsze</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="573"/>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="576"/>
        <source>Tab visibility:</source>
        <translation>Widoczność paska kart:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="583"/>
        <source>New tab next to current tab:</source>
        <translation>Nowa zakładka obok bieżącej zakładki:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="592"/>
        <source>Recently used count:</source>
        <translation>Ostatnio używane liczba:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="623"/>
        <source>Current page in window title:</source>
        <translation>Bieżąca strona w tytule okna:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="600"/>
        <source>File tool bar:</source>
        <translation>Pasek narzędziowy &quot;Plik&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="608"/>
        <source>Edit tool bar:</source>
        <translation>Pasek narzędziowy &quot;Edycja&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="616"/>
        <source>View tool bar:</source>
        <translation>Pasek narzędziowy &quot;Widok&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="630"/>
        <source>Synchronize outline view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="637"/>
        <source>Highlight current thumbnail:</source>
        <translation>Zaznacz bieżącą miniaturkę:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="644"/>
        <source>Limit thumbnails to results:</source>
        <translation>Limit miniatur do:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="674"/>
        <source>Zoom:</source>
        <translation>Powiększenie:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="680"/>
        <source>Rotate:</source>
        <translation>Obrót:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="686"/>
        <source>Scroll:</source>
        <translation>Przewijaj:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="692"/>
        <source>Copy to clipboard:</source>
        <translation>Kopiuj do schowka:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="698"/>
        <source>Add annotation:</source>
        <translation>Dodaj adnotację:</translation>
    </message>
</context>
<context>
    <name>ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <translation>Przejdź wstecz</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <translation>Przejdź naprzód</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <translation>Przesuń w górę</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <translation>Przesuń w dół</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <translation>Idź w lewo</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <translation>Idź w prawo</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <translation>Działanie</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <translation>Sekwencja klawiszy</translation>
    </message>
</context>
<context>
    <name>TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="161"/>
        <source>&amp;Expand all</source>
        <translation>&amp;Rozszerz wszystko</translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="162"/>
        <source>&amp;Collapse all</source>
        <translation>&amp;Zwiń wszystko</translation>
    </message>
</context>
</TS>
