<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="uk_UA">
<context>
    <name>BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="35"/>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Відкрити</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="40"/>
        <source>Open in new &amp;tab</source>
        <translation type="unfinished">Ві&amp;дкрити у новій вкладці</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="50"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">Ви&amp;далити закладку</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="72"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Перехід до сторінки %1</translation>
    </message>
</context>
<context>
    <name>DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="219"/>
        <source>Supported formats (%1)</source>
        <translation type="unfinished">Підтримувані формати (%1)</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Unlock %1</source>
        <translation type="unfinished">Розблокувати %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Password:</source>
        <translation type="unfinished">Пароль:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Information</source>
        <translation type="unfinished">Інформація</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation type="unfinished">Перехід за посиланням заборонено у налаштуваннях.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>Warning</source>
        <translation type="unfinished">Попередження</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">Не знайдено даних SyncTeX для &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1495"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation type="unfinished">Друк &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1641"/>
        <source>Page %1</source>
        <translation type="unfinished">Сторінка %1</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Warning</source>
        <translation type="unfinished">Попередження</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation type="unfinished">Не вдалося відкрити &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="884"/>
        <source>Open</source>
        <translation type="unfinished">Відкрити</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="900"/>
        <source>Open in new tab</source>
        <translation type="unfinished">Відкрити у новій вкладці</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation type="unfinished">Не вдалося оновити &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="929"/>
        <source>Save copy</source>
        <translation type="unfinished">Зберегти копію</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation type="unfinished">Не вдалося зберегти копію &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="946"/>
        <source>Save as</source>
        <translation type="unfinished">Зберегти як</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation type="unfinished">Не вдалося зберегти як &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation type="unfinished">Не вдалося роздрукувати &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Jump to page</source>
        <translation type="unfinished">Перехід до сторінки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Page:</source>
        <translation type="unfinished">Сторінка:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>About qpdfview</source>
        <translation type="unfinished">Про qpdfview</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview — програма для перегляду документів на основі Qt.&lt;/p&gt;&lt;p&gt;Можливості цієї версії:&lt;ul&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1496"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Підтримка PDF на основі Poppler&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1499"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Підтримка PS на основі libspectre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1502"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Підтримка DjVu на основі DjVuLibre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1505"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Підтримка друку за допомогою CUPS&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1507"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 The qpdfview developers&lt;/p&gt;</source>
        <translation type="unfinished">&lt;/ul&gt;&lt;p&gt;Докладніші відомості можна знайти на сторінці &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;&amp;copy; Розробники qpdfview, 2012–2013&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1714"/>
        <source>Page width</source>
        <translation type="unfinished">Ширина сторінки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1715"/>
        <source>Page size</source>
        <translation type="unfinished">Розмір сторінки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1736"/>
        <source>Match &amp;case</source>
        <translation type="unfinished">Враховувати &amp;регістр</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1737"/>
        <source>Highlight &amp;all</source>
        <translation type="unfinished">Виділити &amp;усе</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1781"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Відкрити...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1782"/>
        <source>Open in new &amp;tab...</source>
        <translation type="unfinished">Ві&amp;дкрити у новій вкладці...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1783"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished">&amp;Оновити</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1784"/>
        <source>&amp;Save copy...</source>
        <translation type="unfinished">&amp;Зберегти копію...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1785"/>
        <source>Save &amp;as...</source>
        <translation type="unfinished">Зберегти &amp;як...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1786"/>
        <source>&amp;Print...</source>
        <translation type="unfinished">Д&amp;рукувати...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1787"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">Ви&amp;йти</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1791"/>
        <source>&amp;Previous page</source>
        <translation type="unfinished">&amp;Попередня сторінка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1792"/>
        <source>&amp;Next page</source>
        <translation type="unfinished">&amp;Наступна сторінка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1793"/>
        <source>&amp;First page</source>
        <translation type="unfinished">П&amp;ерша сторінка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1794"/>
        <source>&amp;Last page</source>
        <translation type="unfinished">О&amp;стання сторінка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1796"/>
        <source>&amp;Jump to page...</source>
        <translation type="unfinished">Пе&amp;рейти до сторінки...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1798"/>
        <source>Jump &amp;backward</source>
        <translation type="unfinished">Перейти &amp;назад</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1799"/>
        <source>Jump for&amp;ward</source>
        <translation type="unfinished">Перейти в&amp;перед</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1801"/>
        <source>&amp;Search...</source>
        <translation type="unfinished">&amp;Пошук...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1802"/>
        <source>Find previous</source>
        <translation type="unfinished">Знайти попереднє</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1803"/>
        <source>Find next</source>
        <translation type="unfinished">Знайти наступне</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1804"/>
        <source>Cancel search</source>
        <translation type="unfinished">Скасувати пошук</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1806"/>
        <source>&amp;Copy to clipboard</source>
        <translation type="unfinished">С&amp;копіювати до буфера</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1807"/>
        <source>&amp;Add annotation</source>
        <translation type="unfinished">&amp;Додати коментар</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1809"/>
        <source>Settings...</source>
        <translation type="unfinished">Налаштування...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1813"/>
        <source>&amp;Continuous</source>
        <translation type="unfinished">&amp;Рулоном</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1814"/>
        <source>&amp;Two pages</source>
        <translation type="unfinished">&amp;Дві сторінки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1815"/>
        <source>Two pages &amp;with cover page</source>
        <translation type="unfinished">Дві сторінки та &amp;обкладинка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1816"/>
        <source>&amp;Multiple pages</source>
        <translation type="unfinished">&amp;Кілька сторінок</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1818"/>
        <source>Zoom &amp;in</source>
        <translation type="unfinished">З&amp;більшити</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1819"/>
        <source>Zoom &amp;out</source>
        <translation type="unfinished">З&amp;меншити</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1820"/>
        <source>Original &amp;size</source>
        <translation type="unfinished">По&amp;чатковий розмір</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1822"/>
        <source>Fit to page width</source>
        <translation type="unfinished">За шириною</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1823"/>
        <source>Fit to page size</source>
        <translation type="unfinished">Сторінка цілком</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1825"/>
        <source>Rotate &amp;left</source>
        <translation type="unfinished">Повернути &amp;праворуч</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1826"/>
        <source>Rotate &amp;right</source>
        <translation type="unfinished">Повернути &amp;ліворуч</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1828"/>
        <source>Invert colors</source>
        <translation type="unfinished">Інвертувати кольори</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1830"/>
        <source>Fonts...</source>
        <translation type="unfinished">Шрифти...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1832"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">Повний &amp;екран</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1833"/>
        <source>&amp;Presentation...</source>
        <translation type="unfinished">Пре&amp;зентація...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1837"/>
        <source>&amp;Previous tab</source>
        <translation type="unfinished">&amp;Попередня вкладка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1838"/>
        <source>&amp;Next tab</source>
        <translation type="unfinished">&amp;Наступна вкладка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1840"/>
        <source>&amp;Close tab</source>
        <translation type="unfinished">&amp;Закрити вкладку</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1841"/>
        <source>Close &amp;all tabs</source>
        <translation type="unfinished">Закрити &amp;усі вкладки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1842"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation type="unfinished">Закрити усі вкладки, &amp;крім поточної</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1853"/>
        <source>&amp;Previous bookmark</source>
        <translation type="unfinished">&amp;Попередня закладка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1854"/>
        <source>&amp;Next bookmark</source>
        <translation type="unfinished">&amp;Наступна закладка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1856"/>
        <source>&amp;Add bookmark</source>
        <translation type="unfinished">&amp;Додати закладку</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1857"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Видалити закладку</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1858"/>
        <source>Remove all bookmarks</source>
        <translation type="unfinished">Видалити усі закладки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1862"/>
        <source>&amp;Contents</source>
        <translation type="unfinished">&amp;Зміст</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1863"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;Про програму</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1897"/>
        <location filename="../sources/mainwindow.cpp" line="2011"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Файл</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1900"/>
        <location filename="../sources/mainwindow.cpp" line="2046"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">З&amp;міни</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1903"/>
        <location filename="../sources/mainwindow.cpp" line="2059"/>
        <source>&amp;View</source>
        <translation type="unfinished">П&amp;ерегляд</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1929"/>
        <source>&amp;Outline</source>
        <translation type="unfinished">&amp;Зміст</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1942"/>
        <source>&amp;Properties</source>
        <translation type="unfinished">&amp;Властивості</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1952"/>
        <source>&amp;Thumbnails</source>
        <translation type="unfinished">&amp;Мініатюри</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1964"/>
        <source>&amp;Search</source>
        <translation type="unfinished">&amp;Пошук</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2069"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished">Па&amp;нелі</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2072"/>
        <source>&amp;Docks</source>
        <translation type="unfinished">Пр&amp;ичепи</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2081"/>
        <source>&amp;Tabs</source>
        <translation type="unfinished">В&amp;кладки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2089"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished">&amp;Закладки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2097"/>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Довідка</translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Name</source>
        <translation type="unfinished">Назва</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Embedded</source>
        <translation type="unfinished">Вбудований</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Subset</source>
        <translation type="unfinished">Підмножина</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>File</source>
        <translation type="unfinished">Файл</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>Yes</source>
        <translation type="unfinished">Так</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>No</source>
        <translation type="unfinished">Ні</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Information</source>
        <translation type="unfinished">Відомості</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation type="unfinished">Для додавання або вилучення анотацій слід встановити версію 0.20.1 або новішу бібліотеки Poppler.</translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Title</source>
        <translation type="unfinished">Заголовок</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Created for</source>
        <translation type="unfinished">Створено для</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creator</source>
        <translation type="unfinished">Створено у</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Creation date</source>
        <translation type="unfinished">Дата створення</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Format</source>
        <translation type="unfinished">Формат</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="222"/>
        <source>Language level</source>
        <translation type="unfinished">Рівень мови</translation>
    </message>
</context>
<context>
    <name>PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="333"/>
        <source>Go to page %1.</source>
        <translation type="unfinished">Перейти до сторінки %1.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="337"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation type="unfinished">Перейти на сторінку %1 файла «%2».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="345"/>
        <source>Open &apos;%1&apos;.</source>
        <translation type="unfinished">Відкрити «%1».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="380"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation type="unfinished">Редагувати поле &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="596"/>
        <source>Copy &amp;text</source>
        <translation type="unfinished">Скопіювати &amp;текст</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="597"/>
        <source>Copy &amp;image</source>
        <translation type="unfinished">Скопіювати &amp;зображення</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="598"/>
        <source>Save image to &amp;file...</source>
        <translation type="unfinished">Зберегти зображення у &amp;файл...</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="624"/>
        <source>Save image to file</source>
        <translation type="unfinished">Зберегти зображення у файл</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Warning</source>
        <translation type="unfinished">Попередження</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation type="unfinished">Неможливо зберегти зображення у файл &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="641"/>
        <source>Add &amp;text</source>
        <translation type="unfinished">Додати &amp;текст</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="642"/>
        <source>Add &amp;highlight</source>
        <translation type="unfinished">Додати &amp;підсвічування</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="679"/>
        <source>&amp;Remove annotation</source>
        <translation type="unfinished">&amp;Видалити анотацію</translation>
    </message>
</context>
<context>
    <name>PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="804"/>
        <source>Antialiasing:</source>
        <translation type="unfinished">Згладжування:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="811"/>
        <source>Text antialiasing:</source>
        <translation type="unfinished">Згладжування тексту:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <location filename="../sources/pdfmodel.cpp" line="848"/>
        <source>None</source>
        <translation type="unfinished">Немає</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="819"/>
        <source>Full</source>
        <translation type="unfinished">Повне</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="820"/>
        <source>Reduced</source>
        <translation type="unfinished">Спрощене</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="823"/>
        <location filename="../sources/pdfmodel.cpp" line="830"/>
        <source>Text hinting:</source>
        <translation type="unfinished">Гінтінґ тексту:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="841"/>
        <source>Overprint preview:</source>
        <translation type="unfinished">Перегляд наддруку:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="849"/>
        <source>Solid</source>
        <translation type="unfinished">Суцільні</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="850"/>
        <source>Shaped</source>
        <translation type="unfinished">Надати форму</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="853"/>
        <source>Thin line mode:</source>
        <translation type="unfinished">Режим тонких ліній:</translation>
    </message>
</context>
<context>
    <name>PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Critical</source>
        <translation type="unfinished">Критична помилка</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <source>Could not load PDF plug-in!</source>
        <translation type="unfinished">Не вдалося завантажити додаток роботи з PDF!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <source>Could not load PS plug-in!</source>
        <translation type="unfinished">Не вдалося завантажити додаток роботи з PS!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Could not load DjVu plug-in!</source>
        <translation type="unfinished">Не вдалося завантажити додаток роботи з DjVuPS!</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <translation type="unfinished">Підлаштовування під аркуш:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <translation type="unfinished">Діапазон сторінок:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Всі сторінки</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <translation type="unfinished">Парні сторінки</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <translation type="unfinished">Непарні сторінки</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <translation type="unfinished">Набір сторінок:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <translation type="unfinished">Одна сторінка</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <translation type="unfinished">Дві сторінки</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <translation type="unfinished">Чотири сторінки</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <translation type="unfinished">Шість сторінок</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <translation type="unfinished">Дев’ять сторінок</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <translation type="unfinished">Шістнадцять сторінок</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <translation type="unfinished">Розташовування:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <translation type="unfinished">Знизу вгору і зліва праворуч</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <translation type="unfinished">Знизу вгору і справа ліворуч</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <translation type="unfinished">Зліва праворуч і знизу вгору</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <translation type="unfinished">Зліва праворуч і згори взниз</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <translation type="unfinished">Справа ліворуч і знизу вгору</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <translation type="unfinished">Справа ліворуч і згори вниз</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <translation type="unfinished">Згори вниз і зліва праворуч</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <translation type="unfinished">Згори вниз і справа ліворуч</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <translation type="unfinished">Компонування сторінок:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <translation type="unfinished">Додаткові параметри</translation>
    </message>
</context>
<context>
    <name>PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="236"/>
        <source>Graphics antialias bits:</source>
        <translation type="unfinished">Бітова маска згладжування графіки:</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Text antialias bits:</source>
        <translation type="unfinished">Бітова маска згладжування тексту:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="127"/>
        <source>An empty instance name is not allowed.</source>
        <translation type="unfinished">Порожнє ім&apos;я екземпляру не дозволяється.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="138"/>
        <source>An empty search text is not allowed.</source>
        <translation type="unfinished">Не можна шукати порожній рядок.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="203"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation type="unfinished">Використання &apos;--instance&apos; потребує вказання імені екземпляру.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="209"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation type="unfinished">Використання &apos;--instance&apos; не дозволяється без &apos;--unique&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="215"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation type="unfinished">Використання параметра «--search» вимагає зазначення тексту для пошуку.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="258"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">Не знайдено даних SyncTeX для &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="353"/>
        <source>Could not prepare signal handler.</source>
        <translation type="unfinished">Не вдалося підготувати обробник сигналу.</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="714"/>
        <source>Shift</source>
        <translation type="unfinished">Shift</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="715"/>
        <source>Ctrl</source>
        <translation type="unfinished">Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="716"/>
        <source>Alt</source>
        <translation type="unfinished">Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="717"/>
        <source>Shift and Ctrl</source>
        <translation type="unfinished">Shift і Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="718"/>
        <source>Shift and Alt</source>
        <translation type="unfinished">Shift і Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="719"/>
        <source>Ctrl and Alt</source>
        <translation type="unfinished">Ctrl і Alt</translation>
    </message>
</context>
<context>
    <name>RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="29"/>
        <source>Recently &amp;used</source>
        <translation type="unfinished">Останні відкр&amp;иті</translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="38"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">О&amp;чистити список</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="54"/>
        <source>General</source>
        <translation type="unfinished">Загальне</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="105"/>
        <source>&amp;Behavior</source>
        <translation type="unfinished">&amp;Поведінка</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="106"/>
        <source>&amp;Graphics</source>
        <translation type="unfinished">&amp;Графіка</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="107"/>
        <source>&amp;Interface</source>
        <translation type="unfinished">&amp;Інтерфейс</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="108"/>
        <source>&amp;Shortcuts</source>
        <translation type="unfinished">&amp;Клавіатурні скорочення</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="109"/>
        <source>&amp;Modifiers</source>
        <translation type="unfinished">&amp;Модифікатори</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="115"/>
        <source>Defaults</source>
        <translation type="unfinished">За замовчуванням</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="118"/>
        <source>Defaults on current tab</source>
        <translation type="unfinished">Типовий на поточній вкладці</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="280"/>
        <source>Open URL:</source>
        <translation type="unfinished">Відкривати URL:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="287"/>
        <source>Auto-refresh:</source>
        <translation type="unfinished">Автооновлення:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="293"/>
        <location filename="../sources/settingsdialog.cpp" line="590"/>
        <location filename="../sources/settingsdialog.cpp" line="598"/>
        <location filename="../sources/settingsdialog.cpp" line="606"/>
        <location filename="../sources/settingsdialog.cpp" line="614"/>
        <source>Effective after restart.</source>
        <translation type="unfinished">Діятиме після перезапуску.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="295"/>
        <source>Track recently used:</source>
        <translation type="unfinished">Пам&apos;ятати останні відкриті:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="302"/>
        <source>Restore tabs:</source>
        <translation type="unfinished">Відновлювати вкладки:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="309"/>
        <source>Restore bookmarks:</source>
        <translation type="unfinished">Відновлювати закладки:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="316"/>
        <source>Restore per-file settings:</source>
        <translation type="unfinished">Відновлювати налаштування окремих документів:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="331"/>
        <source>Synchronize presentation:</source>
        <translation type="unfinished">Синхронна презентація:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="337"/>
        <source>Default</source>
        <translation type="unfinished">Типовий</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="340"/>
        <source>Presentation screen:</source>
        <translation type="unfinished">Екран презентації:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="350"/>
        <source>Highlight color:</source>
        <translation type="unfinished">Колір підсвічування:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="358"/>
        <source>None</source>
        <translation type="unfinished">Немає</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="361"/>
        <source>Highlight duration:</source>
        <translation type="unfinished">Тривалість підсвічування:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="371"/>
        <source>Annotation color:</source>
        <translation type="unfinished">Колір анотацій:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="377"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation type="unfinished">&apos;%1&apos; замінюється абсолютним шляхом до файлу. &apos;%2&apos; та &apos;%3&apos; замінюються номером рядка та стовпчика відповідно.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="379"/>
        <source>Source editor:</source>
        <translation type="unfinished">Редактор вихідного файлу:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="411"/>
        <source>Decorate pages:</source>
        <translation type="unfinished">Рамка навколо сторінки:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="418"/>
        <source>Decorate links:</source>
        <translation type="unfinished">Виділяти посилання:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="425"/>
        <source>Decorate form fields:</source>
        <translation type="unfinished">Виділяти поля форм:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="435"/>
        <source>Background color:</source>
        <translation type="unfinished">Колір тла:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="445"/>
        <source>Paper color:</source>
        <translation type="unfinished">Колір паперу:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="453"/>
        <source>Pages per row:</source>
        <translation type="unfinished">Сторінок у ряд:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="463"/>
        <source>Page spacing:</source>
        <translation type="unfinished">Між сторінками:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="473"/>
        <source>Thumbnail spacing:</source>
        <translation type="unfinished">Між мініатюрами:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="483"/>
        <source>Thumbnail size:</source>
        <translation type="unfinished">Розмір мініатюр:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="488"/>
        <location filename="../sources/settingsdialog.cpp" line="489"/>
        <location filename="../sources/settingsdialog.cpp" line="490"/>
        <location filename="../sources/settingsdialog.cpp" line="491"/>
        <location filename="../sources/settingsdialog.cpp" line="492"/>
        <location filename="../sources/settingsdialog.cpp" line="493"/>
        <location filename="../sources/settingsdialog.cpp" line="494"/>
        <location filename="../sources/settingsdialog.cpp" line="495"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 МБ</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="498"/>
        <source>Cache size:</source>
        <translation type="unfinished">Кеш:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="505"/>
        <source>Prefetch:</source>
        <translation type="unfinished">Передзавантаження:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="513"/>
        <source>Prefetch distance:</source>
        <translation type="unfinished">Довжина передзавантаження:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="560"/>
        <source>Top</source>
        <translation type="unfinished">Вгорі</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="561"/>
        <source>Bottom</source>
        <translation type="unfinished">Внизу</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="562"/>
        <source>Left</source>
        <translation type="unfinished">Ліворуч</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="563"/>
        <source>Right</source>
        <translation type="unfinished">Праворуч</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="566"/>
        <source>Tab position:</source>
        <translation type="unfinished">Розташування вкладок:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="571"/>
        <source>As needed</source>
        <translation type="unfinished">За потребою</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="572"/>
        <source>Always</source>
        <translation type="unfinished">Завжди</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="573"/>
        <source>Never</source>
        <translation type="unfinished">Ніколи</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="576"/>
        <source>Tab visibility:</source>
        <translation type="unfinished">Показувати вкладки:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="583"/>
        <source>New tab next to current tab:</source>
        <translation type="unfinished">Нова вкладка поряд з поточною:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="592"/>
        <source>Recently used count:</source>
        <translation type="unfinished">Нещодавно використане число:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="600"/>
        <source>File tool bar:</source>
        <translation type="unfinished">Панель &quot;Файл&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="608"/>
        <source>Edit tool bar:</source>
        <translation type="unfinished">Панель &quot;Редагувати&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="616"/>
        <source>View tool bar:</source>
        <translation type="unfinished">Панель &quot;Перегляд&quot;:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="623"/>
        <source>Current page in window title:</source>
        <translation type="unfinished">Поточна сторінка у заголовку вікна:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="630"/>
        <source>Synchronize outline view:</source>
        <translation type="unfinished">Синхронізувати перегляд ескізу:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="637"/>
        <source>Highlight current thumbnail:</source>
        <translation type="unfinished">Підсвічування поточної мініатюри:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="644"/>
        <source>Limit thumbnails to results:</source>
        <translation type="unfinished">Обмежити мініатюри результатами:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="674"/>
        <source>Zoom:</source>
        <translation type="unfinished">Масштаб:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="680"/>
        <source>Rotate:</source>
        <translation type="unfinished">Обертання:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="686"/>
        <source>Scroll:</source>
        <translation type="unfinished">Гортання:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="692"/>
        <source>Copy to clipboard:</source>
        <translation type="unfinished">Копіювання до буфера:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="698"/>
        <source>Add annotation:</source>
        <translation type="unfinished">Додавання анотацій:</translation>
    </message>
</context>
<context>
    <name>ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <translation type="unfinished">Дія</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <translation type="unfinished">Комбінація клавіш</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <translation type="unfinished">Гортати назад</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <translation type="unfinished">Гортати вперед</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <translation type="unfinished">Вгору</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <translation type="unfinished">Вниз</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <translation type="unfinished">Ліворуч</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <translation type="unfinished">Праворуч</translation>
    </message>
</context>
<context>
    <name>TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="161"/>
        <source>&amp;Expand all</source>
        <translation type="unfinished">&amp;Розгорнути все</translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="162"/>
        <source>&amp;Collapse all</source>
        <translation type="unfinished">&amp;Згорнути все</translation>
    </message>
</context>
</TS>
