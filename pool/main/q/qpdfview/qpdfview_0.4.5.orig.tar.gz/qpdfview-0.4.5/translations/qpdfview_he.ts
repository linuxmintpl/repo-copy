<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="he_IL">
<context>
    <name>BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="35"/>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;פתיחה</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="40"/>
        <source>Open in new &amp;tab</source>
        <translation type="unfinished">פתיחה ב&amp;לשונית חדשה</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="50"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">הס&amp;רת הסימנייה</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="72"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">מעבר לעמוד %1</translation>
    </message>
</context>
<context>
    <name>DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="219"/>
        <source>Supported formats (%1)</source>
        <translation type="unfinished">תבניות נתמכות (%1)</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Unlock %1</source>
        <translation type="unfinished">שחרור %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="525"/>
        <source>Password:</source>
        <translation type="unfinished">ססמה:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Information</source>
        <translation type="unfinished">פרטים</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1073"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation type="unfinished">פתיחת כתובות מנוטרלת בהגדרות.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>Warning</source>
        <translation type="unfinished">אזהרה</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1125"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">לא ניתן למצוא את נתוני ה־SyncTeX עבור &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1495"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation type="unfinished">&apos;%1&apos; בהדפסה...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1641"/>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Warning</source>
        <translation type="unfinished">אזהרה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="268"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן לפתוח את &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="884"/>
        <source>Open</source>
        <translation type="unfinished">פתיחה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="900"/>
        <source>Open in new tab</source>
        <translation type="unfinished">פתיחה בלשונית חדשה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="921"/>
        <location filename="../sources/mainwindow.cpp" line="1115"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן לרענן את &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="929"/>
        <source>Save copy</source>
        <translation type="unfinished">שמירת עותק</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="939"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן לשמור עותק למיקום &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="946"/>
        <source>Save as</source>
        <translation type="unfinished">שמירה בשם</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="958"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן לשמור בשם ‚%1‘.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="994"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן להדפיס את &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Jump to page</source>
        <translation type="unfinished">מעבר לעמוד</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1033"/>
        <source>Page:</source>
        <translation type="unfinished">עמוד:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>About qpdfview</source>
        <translation type="unfinished">על אודות qpdfview</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview הנו מציג מסמכים בלשוניות לסביבת Qt.&lt;/p&gt;&lt;p&gt;גרסה זו כוללת:&lt;ul&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1496"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;תמיכה ב־PDF באמצעות Poppler&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1499"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;תמיכה ב־PS באמצעות libspectre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1502"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;תמיכה ב־DjVu באמצעות DjVuLibre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1505"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;תמיכה בהדפסה באמצעות CUPS&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1507"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 The qpdfview developers&lt;/p&gt;</source>
        <translation type="unfinished">&lt;/ul&gt;&lt;p&gt;ניתן לעיין באתר &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; למידע נוסף.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 המתכנתים של qpdfview&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1714"/>
        <source>Page width</source>
        <translation type="unfinished">רוחב העמוד</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1715"/>
        <source>Page size</source>
        <translation type="unfinished">גודל עמוד</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1736"/>
        <source>Match &amp;case</source>
        <translation type="unfinished">התאמת &amp;רישיות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1737"/>
        <source>Highlight &amp;all</source>
        <translation type="unfinished">ה&amp;דגשה של הכול</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1781"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;פתיחה...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1782"/>
        <source>Open in new &amp;tab...</source>
        <translation type="unfinished">פתיחה ב&amp;לשונית חדשה...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1783"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished">&amp;רענון</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1784"/>
        <source>&amp;Save copy...</source>
        <translation type="unfinished">שמירת &amp;עותק...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1785"/>
        <source>Save &amp;as...</source>
        <translation type="unfinished">שמירה &amp;בשם...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1786"/>
        <source>&amp;Print...</source>
        <translation type="unfinished">הד&amp;פסה...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1787"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">י&amp;ציאה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1791"/>
        <source>&amp;Previous page</source>
        <translation type="unfinished">העמוד ה&amp;קודם</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1792"/>
        <source>&amp;Next page</source>
        <translation type="unfinished">העמוד ה&amp;בא</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1793"/>
        <source>&amp;First page</source>
        <translation type="unfinished">העמוד ה&amp;ראשון</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1794"/>
        <source>&amp;Last page</source>
        <translation type="unfinished">העמוד ה&amp;אחרון</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1796"/>
        <source>&amp;Jump to page...</source>
        <translation type="unfinished">מ&amp;עבר לעמוד...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1798"/>
        <source>Jump &amp;backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1799"/>
        <source>Jump for&amp;ward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1801"/>
        <source>&amp;Search...</source>
        <translation type="unfinished">&amp;חיפוש...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1802"/>
        <source>Find previous</source>
        <translation type="unfinished">חיפוש הקודם</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1803"/>
        <source>Find next</source>
        <translation type="unfinished">חיפוש הבא</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1804"/>
        <source>Cancel search</source>
        <translation type="unfinished">ביטול החיפוש</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1806"/>
        <source>&amp;Copy to clipboard</source>
        <translation type="unfinished">ה&amp;עתקה ללוח הגזירים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1807"/>
        <source>&amp;Add annotation</source>
        <translation type="unfinished">הוספת ה&amp;ערה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1809"/>
        <source>Settings...</source>
        <translation type="unfinished">הגדרות...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1813"/>
        <source>&amp;Continuous</source>
        <translation type="unfinished">מ&amp;תמשך</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1814"/>
        <source>&amp;Two pages</source>
        <translation type="unfinished">&amp;שני עמודים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1815"/>
        <source>Two pages &amp;with cover page</source>
        <translation type="unfinished">&amp;שני עמודים עם עמוד שער</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1816"/>
        <source>&amp;Multiple pages</source>
        <translation type="unfinished">מ&amp;ספר עמודים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1818"/>
        <source>Zoom &amp;in</source>
        <translation type="unfinished">הת&amp;קרבות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1819"/>
        <source>Zoom &amp;out</source>
        <translation type="unfinished">הת&amp;רחקות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1820"/>
        <source>Original &amp;size</source>
        <translation type="unfinished">גודל מ&amp;קורי</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1822"/>
        <source>Fit to page width</source>
        <translation type="unfinished">התאמת העמוד לרוחב</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1823"/>
        <source>Fit to page size</source>
        <translation type="unfinished">התאמה לגודל העמוד</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1825"/>
        <source>Rotate &amp;left</source>
        <translation type="unfinished">הטייה &amp;שמאלה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1826"/>
        <source>Rotate &amp;right</source>
        <translation type="unfinished">הטייה ימי&amp;נה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1828"/>
        <source>Invert colors</source>
        <translation type="unfinished">היפוך צבעים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1830"/>
        <source>Fonts...</source>
        <translation type="unfinished">גופנים...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1832"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">מ&amp;סך מלא</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1833"/>
        <source>&amp;Presentation...</source>
        <translation type="unfinished">מ&amp;צגת...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1837"/>
        <source>&amp;Previous tab</source>
        <translation type="unfinished">הלשונית ה&amp;קודמת</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1838"/>
        <source>&amp;Next tab</source>
        <translation type="unfinished">הלשונית ה&amp;באה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1840"/>
        <source>&amp;Close tab</source>
        <translation type="unfinished">&amp;סגירת הלשונית</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1841"/>
        <source>Close &amp;all tabs</source>
        <translation type="unfinished">סגירת &amp;כל הלשוניות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1842"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation type="unfinished">סגירת כל הלשוניות &amp;פרטי לנוכחית</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1853"/>
        <source>&amp;Previous bookmark</source>
        <translation type="unfinished">הסימנייה ה&amp;קודמת</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1854"/>
        <source>&amp;Next bookmark</source>
        <translation type="unfinished">הסימנייה ה&amp;באה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1856"/>
        <source>&amp;Add bookmark</source>
        <translation type="unfinished">הוס&amp;פת סימנייה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1857"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">הס&amp;רת הסימנייה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1858"/>
        <source>Remove all bookmarks</source>
        <translation type="unfinished">הסרת כל הסימניות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1862"/>
        <source>&amp;Contents</source>
        <translation type="unfinished">ת&amp;כנים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1863"/>
        <source>&amp;About</source>
        <translation type="unfinished">על &amp;אודות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1897"/>
        <location filename="../sources/mainwindow.cpp" line="2011"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;קובץ</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1900"/>
        <location filename="../sources/mainwindow.cpp" line="2046"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">ע&amp;ריכה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1903"/>
        <location filename="../sources/mainwindow.cpp" line="2059"/>
        <source>&amp;View</source>
        <translation type="unfinished">ת&amp;צוגה</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1964"/>
        <source>&amp;Search</source>
        <translation type="unfinished">&amp;חיפוש</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1929"/>
        <source>&amp;Outline</source>
        <translation type="unfinished">מ&amp;תאר</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1942"/>
        <source>&amp;Properties</source>
        <translation type="unfinished">מ&amp;אפיינים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1952"/>
        <source>&amp;Thumbnails</source>
        <translation type="unfinished">תמונות ממו&amp;זערות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2069"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished">סרגלי &amp;כלים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2072"/>
        <source>&amp;Docks</source>
        <translation type="unfinished">מ&amp;עגנים</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2081"/>
        <source>&amp;Tabs</source>
        <translation type="unfinished">&amp;לשוניות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2089"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished">&amp;סימניות</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2097"/>
        <source>&amp;Help</source>
        <translation type="unfinished">ע&amp;זרה</translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Name</source>
        <translation type="unfinished">שם</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Type</source>
        <translation type="unfinished">סוג</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Embedded</source>
        <translation type="unfinished">מוטמע</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>Subset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="780"/>
        <source>File</source>
        <translation type="unfinished">קובץ</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>Yes</source>
        <translation type="unfinished">כן</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="788"/>
        <location filename="../sources/pdfmodel.cpp" line="789"/>
        <source>No</source>
        <translation type="unfinished">לא</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Information</source>
        <translation type="unfinished">פרטים</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="371"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Title</source>
        <translation type="unfinished">כותרת</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Created for</source>
        <translation type="unfinished">נוצר עבור</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creator</source>
        <translation type="unfinished">יוצר</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Creation date</source>
        <translation type="unfinished">תאריך היצירה</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Format</source>
        <translation type="unfinished">עיצוב</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="222"/>
        <source>Language level</source>
        <translation type="unfinished">רמת השפה</translation>
    </message>
</context>
<context>
    <name>PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="333"/>
        <source>Go to page %1.</source>
        <translation type="unfinished">מעבר לעמוד %1.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="337"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation type="unfinished">מעבר לעמוד %1 בקובץ &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="345"/>
        <source>Open &apos;%1&apos;.</source>
        <translation type="unfinished">פתיחת &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="380"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation type="unfinished">עריכת שדה הטופס &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="596"/>
        <source>Copy &amp;text</source>
        <translation type="unfinished">ה&amp;עתקת טקסט</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="597"/>
        <source>Copy &amp;image</source>
        <translation type="unfinished">העתקת ת&amp;מונה</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="598"/>
        <source>Save image to &amp;file...</source>
        <translation type="unfinished">שמירת תמונה ל&amp;קובץ...</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="624"/>
        <source>Save image to file</source>
        <translation type="unfinished">שמירת תמונה לקובץ</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Warning</source>
        <translation type="unfinished">אזהרה</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="628"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation type="unfinished">לא ניתן לשמור את התמונה לקובץ &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="641"/>
        <source>Add &amp;text</source>
        <translation type="unfinished">הוספת &amp;טקסט</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="642"/>
        <source>Add &amp;highlight</source>
        <translation type="unfinished">הוספת ה&amp;דגשה</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="679"/>
        <source>&amp;Remove annotation</source>
        <translation type="unfinished">הסרת ה&amp;ערה</translation>
    </message>
</context>
<context>
    <name>PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="804"/>
        <source>Antialiasing:</source>
        <translation type="unfinished">החלקת קצוות:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="811"/>
        <source>Text antialiasing:</source>
        <translation type="unfinished">החלקת קצוות גופנים:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <location filename="../sources/pdfmodel.cpp" line="848"/>
        <source>None</source>
        <translation type="unfinished">אין</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="819"/>
        <source>Full</source>
        <translation type="unfinished">מלא</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="820"/>
        <source>Reduced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="823"/>
        <location filename="../sources/pdfmodel.cpp" line="830"/>
        <source>Text hinting:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="841"/>
        <source>Overprint preview:</source>
        <translation type="unfinished">טווחי</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="849"/>
        <source>Solid</source>
        <translation type="unfinished">אחיד</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="850"/>
        <source>Shaped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="853"/>
        <source>Thin line mode:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Critical</source>
        <translation type="unfinished">קריטי</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <source>Could not load PDF plug-in!</source>
        <translation type="unfinished">לא ניתן לטעון את תוסף ה־PDF!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <source>Could not load PS plug-in!</source>
        <translation type="unfinished">לא ניתן לטעון את תוסף ה־PS!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Could not load DjVu plug-in!</source>
        <translation type="unfinished">לא ניתן לטעון את תוסף ה־DjVu!</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <translation type="unfinished">התאמה לעמוד:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <translation type="unfinished">טווחי עמודים:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">כל העמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <translation type="unfinished">עמודים זוגיים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <translation type="unfinished">עמודים אי־זוגיים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <translation type="unfinished">עמוד יחיד</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <translation type="unfinished">שני עמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <translation type="unfinished">ארבעה עמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <translation type="unfinished">שישה עמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <translation type="unfinished">תשעה עמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <translation type="unfinished">שישה עשר עמודים</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <translation type="unfinished">משמאל לימין ומלמטה למעלה</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <translation type="unfinished">משמאל לימין ומלמעלה למטה</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <translation type="unfinished">מימין לשמאל ומלמטה למעלה</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <translation type="unfinished">מימין לשמאל ומלמעלה למטה</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <translation type="unfinished">מלמעלה למטה ומשמאל לימין</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <translation type="unfinished">מלמעלה למטה ומימין לשמאל</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <translation type="unfinished">אפשרויות מורחבות</translation>
    </message>
</context>
<context>
    <name>PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="236"/>
        <source>Graphics antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Text antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="127"/>
        <source>An empty instance name is not allowed.</source>
        <translation type="unfinished">An empty instance name is not allowed.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="138"/>
        <source>An empty search text is not allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="203"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation type="unfinished">Using &apos;--instance&apos; requires an instance name.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="209"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation type="unfinished">Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="215"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="258"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">לא ניתן למצוא את נתוני ה־SyncTeX עבור &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="353"/>
        <source>Could not prepare signal handler.</source>
        <translation type="unfinished">לא ניתן להכין את המטפל באותות.</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="714"/>
        <source>Shift</source>
        <translation type="unfinished">Shift</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="715"/>
        <source>Ctrl</source>
        <translation type="unfinished">Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="716"/>
        <source>Alt</source>
        <translation type="unfinished">Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="717"/>
        <source>Shift and Ctrl</source>
        <translation type="unfinished">Shift ו־Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="718"/>
        <source>Shift and Alt</source>
        <translation type="unfinished">Shift ו־Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="719"/>
        <source>Ctrl and Alt</source>
        <translation type="unfinished">Ctrl ו־Alt</translation>
    </message>
</context>
<context>
    <name>RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="29"/>
        <source>Recently &amp;used</source>
        <translation type="unfinished">בשימוש לא&amp;חרונה</translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="38"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;פינוי הרשימה</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="54"/>
        <source>General</source>
        <translation type="unfinished">כללי</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="105"/>
        <source>&amp;Behavior</source>
        <translation type="unfinished">הת&amp;נהגות</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="106"/>
        <source>&amp;Graphics</source>
        <translation type="unfinished">&amp;גרפיקה</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="107"/>
        <source>&amp;Interface</source>
        <translation type="unfinished">מ&amp;נשק</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="108"/>
        <source>&amp;Shortcuts</source>
        <translation type="unfinished">&amp;קיצורי מקשים</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="109"/>
        <source>&amp;Modifiers</source>
        <translation type="unfinished">מקשי ה&amp;חלפה</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="115"/>
        <source>Defaults</source>
        <translation type="unfinished">בררות מחדל</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="118"/>
        <source>Defaults on current tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="280"/>
        <source>Open URL:</source>
        <translation type="unfinished">פתיחת כתובת:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="287"/>
        <source>Auto-refresh:</source>
        <translation type="unfinished">&amp;רענון אוטומטי:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="293"/>
        <location filename="../sources/settingsdialog.cpp" line="590"/>
        <location filename="../sources/settingsdialog.cpp" line="598"/>
        <location filename="../sources/settingsdialog.cpp" line="606"/>
        <location filename="../sources/settingsdialog.cpp" line="614"/>
        <source>Effective after restart.</source>
        <translation type="unfinished">ייכנס לתוקף אחרי הפעלה מחדש.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="295"/>
        <source>Track recently used:</source>
        <translation type="unfinished">מעקב אחר האחרונים בשימוש:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="302"/>
        <source>Restore tabs:</source>
        <translation type="unfinished">שחזור לשוניות:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="309"/>
        <source>Restore bookmarks:</source>
        <translation type="unfinished">שחזור סימניות:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="316"/>
        <source>Restore per-file settings:</source>
        <translation type="unfinished">שחזור ההגדרות לפי קובץ:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="331"/>
        <source>Synchronize presentation:</source>
        <translation type="unfinished">סנכרון מצגת:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="337"/>
        <source>Default</source>
        <translation type="unfinished">בררת מחדל</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="340"/>
        <source>Presentation screen:</source>
        <translation type="unfinished">מסך המצגת:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="350"/>
        <source>Highlight color:</source>
        <translation type="unfinished">צבע ההדגשה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="358"/>
        <source>None</source>
        <translation type="unfinished">ללא</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="361"/>
        <source>Highlight duration:</source>
        <translation type="unfinished">משך ההדגשה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="371"/>
        <source>Annotation color:</source>
        <translation type="unfinished">צבע ההערות:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="377"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation type="unfinished">&apos;%1&apos; יוחלף בנתיב המלא והמוחלט. &apos;%2&apos; ו־&apos;%3&apos; יוחלפו בשורה ובמספר העמודה בהתאמה.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="379"/>
        <source>Source editor:</source>
        <translation type="unfinished">עורך המקור:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="411"/>
        <source>Decorate pages:</source>
        <translation type="unfinished">קישוט עמודים:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="418"/>
        <source>Decorate links:</source>
        <translation type="unfinished">קישוט קישורים:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="425"/>
        <source>Decorate form fields:</source>
        <translation type="unfinished">עיצוב שדות הטופס:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="435"/>
        <source>Background color:</source>
        <translation type="unfinished">צבע הרקע:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="445"/>
        <source>Paper color:</source>
        <translation type="unfinished">צבע הנייר:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="453"/>
        <source>Pages per row:</source>
        <translation type="unfinished">עמודים בשורה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="463"/>
        <source>Page spacing:</source>
        <translation type="unfinished">ריווח עמודים:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="473"/>
        <source>Thumbnail spacing:</source>
        <translation type="unfinished">ריווח בין התמונות הממוזערות:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="483"/>
        <source>Thumbnail size:</source>
        <translation type="unfinished">גודל תמונה ממוזערת:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="488"/>
        <location filename="../sources/settingsdialog.cpp" line="489"/>
        <location filename="../sources/settingsdialog.cpp" line="490"/>
        <location filename="../sources/settingsdialog.cpp" line="491"/>
        <location filename="../sources/settingsdialog.cpp" line="492"/>
        <location filename="../sources/settingsdialog.cpp" line="493"/>
        <location filename="../sources/settingsdialog.cpp" line="494"/>
        <location filename="../sources/settingsdialog.cpp" line="495"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 מ״ב</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="498"/>
        <source>Cache size:</source>
        <translation type="unfinished">גודל מטמון:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="505"/>
        <source>Prefetch:</source>
        <translation type="unfinished">אחזור קדם:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="513"/>
        <source>Prefetch distance:</source>
        <translation type="unfinished">מרחק בין אחזורי הקדם:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="560"/>
        <source>Top</source>
        <translation type="unfinished">למעלה</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="561"/>
        <source>Bottom</source>
        <translation type="unfinished">למטה</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="562"/>
        <source>Left</source>
        <translation type="unfinished">משמאל</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="563"/>
        <source>Right</source>
        <translation type="unfinished">מימין</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="566"/>
        <source>Tab position:</source>
        <translation type="unfinished">מיקום הלשונית:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="571"/>
        <source>As needed</source>
        <translation type="unfinished">לפי הצורך</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="572"/>
        <source>Always</source>
        <translation type="unfinished">תמיד</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="573"/>
        <source>Never</source>
        <translation type="unfinished">לעולם לא</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="576"/>
        <source>Tab visibility:</source>
        <translation type="unfinished">הופעת הלשונית:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="583"/>
        <source>New tab next to current tab:</source>
        <translation type="unfinished">לשונית חדשה ליד הלשונית הנוכחית:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="592"/>
        <source>Recently used count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="600"/>
        <source>File tool bar:</source>
        <translation type="unfinished">סרגל הכלים קובץ:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="608"/>
        <source>Edit tool bar:</source>
        <translation type="unfinished">סרגל הכלים עריכה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="616"/>
        <source>View tool bar:</source>
        <translation type="unfinished">סרגל כלים הצגה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="623"/>
        <source>Current page in window title:</source>
        <translation type="unfinished">העמוד הנוכחי בכותרת החלון:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="630"/>
        <source>Synchronize outline view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="637"/>
        <source>Highlight current thumbnail:</source>
        <translation type="unfinished">הדגשת התמונה הממוזערת הנוכחית:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="644"/>
        <source>Limit thumbnails to results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="674"/>
        <source>Zoom:</source>
        <translation type="unfinished">מרחק מתצוגה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="680"/>
        <source>Rotate:</source>
        <translation type="unfinished">סיבוב:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="686"/>
        <source>Scroll:</source>
        <translation type="unfinished">גלילה:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="692"/>
        <source>Copy to clipboard:</source>
        <translation type="unfinished">העתקה ללוח הגזירים:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="698"/>
        <source>Add annotation:</source>
        <translation type="unfinished">הוספת הערה:</translation>
    </message>
</context>
<context>
    <name>ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <translation type="unfinished">פעולה</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <translation type="unfinished">צירוף מקשים</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <translation type="unfinished">דילוג אחורה</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <translation type="unfinished">דילוג קדימה</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <translation type="unfinished">הזזה למטה</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <translation type="unfinished">הזזה שמאלה</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <translation type="unfinished">הזזה ימינה</translation>
    </message>
</context>
<context>
    <name>TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="161"/>
        <source>&amp;Expand all</source>
        <translation type="unfinished">ה&amp;רחבה של הכול</translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="162"/>
        <source>&amp;Collapse all</source>
        <translation type="unfinished">&amp;צמצום של הכול</translation>
    </message>
</context>
</TS>
